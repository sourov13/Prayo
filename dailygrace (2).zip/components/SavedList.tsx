import React from 'react';
import { Trash2, Share2, Sun, Moon, Heart, Bookmark } from 'lucide-react';
import { AppTab, GeneratedContent } from '../types';

interface SavedListProps {
  items: GeneratedContent[];
  onDelete: (id: string) => void;
}

const SavedList: React.FC<SavedListProps> = ({ items, onDelete }) => {
  const handleShare = async (text: string) => {
    if (navigator.share) {
      await navigator.share({ title: 'DailyGrace', text });
    } else {
      await navigator.clipboard.writeText(text);
      alert('Copied!');
    }
  };

  const getIcon = (type: AppTab) => {
    switch(type) {
      case AppTab.Morning: return <Sun size={16} className="text-dawn-500" />;
      case AppTab.Night: return <Moon size={16} className="text-dusk-500" />;
      case AppTab.Relationships: return <Heart size={16} className="text-rose-500" />;
      default: return null;
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-gray-400 p-8 text-center">
        <Bookmark size={48} className="mb-4 opacity-20" />
        <p className="text-lg font-medium">No saved items yet.</p>
        <p className="text-sm">Save your favorite prayers and quotes to read them here.</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-4 pb-24">
      <h2 className="text-2xl font-serif font-bold text-gray-800 mb-6 px-2">Your Collection</h2>
      {items.map((item) => (
        <div key={item.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
               {getIcon(item.type)}
               <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                 {item.type === AppTab.Morning ? 'Morning Prayer' : item.type === AppTab.Night ? 'Night Reflection' : 'Relationship Quote'}
               </span>
            </div>
            <span className="text-xs text-gray-400">
              {new Date(item.timestamp).toLocaleDateString()}
            </span>
          </div>
          
          <p className="font-serif text-gray-800 leading-relaxed">
            {item.text}
          </p>

          <div className="flex justify-end items-center gap-3 mt-2 border-t border-gray-50 pt-3">
            <button 
              onClick={() => handleShare(item.text)}
              className="text-gray-400 hover:text-gray-600 p-2"
            >
              <Share2 size={16} />
            </button>
            <button 
              onClick={() => onDelete(item.id)}
              className="text-gray-400 hover:text-red-500 p-2"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SavedList;