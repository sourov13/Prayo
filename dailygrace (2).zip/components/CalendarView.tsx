import React from 'react';
import { ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface CalendarViewProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  scheduledDates: string[]; // Dates that have content (YYYY-MM-DD)
}

const CalendarView: React.FC<CalendarViewProps> = ({ selectedDate, onDateSelect, scheduledDates }) => {
  const [viewDate, setViewDate] = React.useState(new Date(selectedDate));

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const handlePrevMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));
  };

  const renderCalendarDays = () => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    
    // Empty slots for previous month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-12 w-full" />);
    }

    const today = new Date();
    today.setHours(0,0,0,0);

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateString = date.toISOString().split('T')[0];
      const isSelected = date.toDateString() === selectedDate.toDateString();
      const isToday = date.toDateString() === today.toDateString();
      const hasContent = scheduledDates.includes(dateString);

      days.push(
        <button
          key={day}
          onClick={() => onDateSelect(date)}
          className={`
            relative h-12 w-full flex flex-col items-center justify-center rounded-xl transition-all duration-200
            ${isSelected ? 'bg-gray-900 text-white shadow-lg scale-105 z-10' : 'hover:bg-gray-100 text-gray-700'}
            ${isToday && !isSelected ? 'text-rose-500 font-bold bg-rose-50' : ''}
          `}
        >
          <span className="text-sm">{day}</span>
          {hasContent && !isSelected && (
            <span className="absolute bottom-1 w-1 h-1 bg-green-500 rounded-full"></span>
          )}
          {isSelected && hasContent && (
             <Check size={10} className="absolute bottom-1 text-white/70" />
          )}
        </button>
      );
    }
    return days;
  };

  return (
    <div className="w-full max-w-md mx-auto p-4 animate-fade-in">
      <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <button onClick={handlePrevMonth} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-900 transition-colors">
            <ChevronLeft size={20} />
          </button>
          <h2 className="text-lg font-serif font-bold text-gray-900">
            {viewDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h2>
          <button onClick={handleNextMonth} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-900 transition-colors">
            <ChevronRight size={20} />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-2">
          {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
            <div key={i} className="text-center text-[10px] font-bold text-gray-400 uppercase tracking-widest py-2">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {renderCalendarDays()}
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-50 text-center">
            <p className="text-xs text-gray-400">
                Select a date to plan or view your daily prayer.
            </p>
        </div>
      </div>
    </div>
  );
};

export default CalendarView;