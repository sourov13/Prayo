import React, { useRef, useState } from 'react';
import { Share2, Bookmark, BookmarkCheck, RefreshCw, Download, Image as ImageIcon } from 'lucide-react';
import { AppTab, GeneratedContent } from '../types';
import html2canvas from 'html2canvas';

interface ContentCardProps {
  content: GeneratedContent | null;
  isLoading: boolean;
  onGenerate: () => void;
  onSave: (content: GeneratedContent) => void;
  isSaved: boolean;
  tab: AppTab;
  date?: Date;
}

const ContentCard: React.FC<ContentCardProps> = ({ 
  content, 
  isLoading, 
  onGenerate, 
  onSave, 
  isSaved,
  tab,
  date
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [bgImage, setBgImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getThemeStyles = () => {
    if (bgImage) return "text-white shadow-xl border-none"; // Styles when image is active

    switch (tab) {
      case AppTab.Morning:
        return "bg-gradient-to-br from-dawn-50 to-orange-50 text-dawn-900 border-dawn-100 shadow-orange-100/50";
      case AppTab.Night:
        return "bg-gradient-to-br from-dusk-50 to-indigo-50 text-dusk-900 border-dusk-100 shadow-indigo-100/50";
      case AppTab.Relationships:
        return "bg-gradient-to-br from-rose-50 to-pink-50 text-rose-900 border-rose-100 shadow-rose-100/50";
      default:
        return "bg-white text-gray-900 border-gray-200";
    }
  };

  const getButtonStyles = () => {
    switch (tab) {
      case AppTab.Morning: return "bg-dawn-500 hover:bg-dawn-600 text-white shadow-dawn-200";
      case AppTab.Night: return "bg-dusk-500 hover:bg-dusk-600 text-white shadow-dusk-200";
      case AppTab.Relationships: return "bg-rose-500 hover:bg-rose-600 text-white shadow-rose-200";
      default: return "bg-gray-900 text-white";
    }
  };

  const handleShare = async () => {
    if (!content) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'DailyGrace',
          text: content.text,
        });
      } catch (err) {
        console.error('Share failed', err);
      }
    } else {
      await navigator.clipboard.writeText(content.text);
      alert('Copied to clipboard!');
    }
  };

  const handleDownload = async () => {
    if (!cardRef.current) return;
    
    try {
      // Temporarily hide actions for screenshot
      const actions = cardRef.current.querySelector('.card-actions') as HTMLElement;
      if (actions) actions.style.display = 'none';
      
      const canvas = await html2canvas(cardRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: bgImage ? null : '#ffffff', // Transparent if bg image
      });

      if (actions) actions.style.display = 'flex';

      const link = document.createElement('a');
      link.download = `dailygrace-${new Date().toISOString().split('T')[0]}.jpg`;
      link.href = canvas.toDataURL('image/jpeg', 0.9);
      link.click();
    } catch (err) {
      console.error("Download failed", err);
      alert("Could not create image.");
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBgImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const formattedDate = date ? new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).format(date) : null;

  return (
    <div className="w-full max-w-md mx-auto my-auto py-4">
      <div 
        ref={cardRef}
        className={`relative w-full p-8 rounded-[2rem] shadow-xl border overflow-hidden ${getThemeStyles()} transition-all duration-500 min-h-[400px] flex flex-col justify-between`}
        style={bgImage ? { 
          backgroundImage: `url(${bgImage})`, 
          backgroundSize: 'cover', 
          backgroundPosition: 'center' 
        } : {}}
      >
        {/* Overlay for readability when background image is present */}
        {bgImage && <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px] z-0"></div>}

        {/* Hidden File Input */}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImageUpload} 
          accept="image/*" 
          className="hidden" 
        />
        
        {/* Decorative Quote Icon */}
        <div className={`absolute top-6 left-6 z-10 pointer-events-none ${bgImage ? 'opacity-40' : 'opacity-20'}`}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
            <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V11C14.017 11.5523 13.5693 12 13.017 12H12.017V5H22.017V15C22.017 18.3137 19.3307 21 16.017 21H14.017ZM5.01697 21L5.01697 18C5.01697 16.8954 5.9124 16 7.01697 16H10.017C10.5693 16 11.017 15.5523 11.017 15V9C11.017 8.44772 10.5693 8 10.017 8H6.01697C5.46468 8 5.01697 8.44772 5.01697 9V11C5.01697 11.5523 4.56925 12 4.01697 12H3.01697V5H13.017V15C13.017 18.3137 10.3307 21 7.01697 21H5.01697Z" />
          </svg>
        </div>

        {/* Date Badge */}
        {formattedDate && (
          <div className="absolute top-6 right-6 z-10">
            <span className={`text-[10px] uppercase font-bold tracking-widest px-2 py-1 rounded-md ${bgImage ? 'bg-white/20 text-white' : 'bg-black/5 text-gray-500'}`}>
              {formattedDate}
            </span>
          </div>
        )}

        <div className="relative z-10 flex-1 flex flex-col justify-center items-center text-center mt-8">
          {isLoading ? (
             <div className="animate-pulse flex flex-col items-center space-y-4 w-full py-8">
               <div className="h-4 bg-current opacity-10 rounded w-3/4"></div>
               <div className="h-4 bg-current opacity-10 rounded w-5/6"></div>
               <div className="h-4 bg-current opacity-10 rounded w-2/3"></div>
               <div className="h-4 bg-current opacity-10 rounded w-4/5"></div>
             </div>
          ) : content ? (
            <div className="py-2">
              {content.theme && (
                <span className={`block mb-6 text-xs font-bold uppercase tracking-[0.2em] ${bgImage ? 'opacity-80' : 'opacity-60'}`}>
                  {content.theme}
                </span>
              )}
              {/* Added 'selectable-text' class to allow user to copy this specific text */}
              <p className={`selectable-text font-serif text-xl md:text-2xl leading-relaxed drop-shadow-sm`}>
                {content.text}
              </p>
            </div>
          ) : (
            <p className="opacity-50 text-sm font-medium">Tap 'New' to receive your message...</p>
          )}
        </div>

        {/* Action Bar */}
        <div className="card-actions relative z-10 flex justify-between items-center mt-8 pt-6 border-t border-current border-opacity-10">
          <div className="flex gap-1">
             <button 
                onClick={handleShare}
                className="p-3 rounded-full hover:bg-black/5 active:bg-black/10 transition-colors"
                aria-label="Share"
                disabled={!content || isLoading}
            >
                <Share2 size={20} />
            </button>
            <button 
                onClick={triggerFileInput}
                className="p-3 rounded-full hover:bg-black/5 active:bg-black/10 transition-colors"
                aria-label="Set Background"
                disabled={isLoading}
            >
                <ImageIcon size={20} />
            </button>
            <button 
                onClick={handleDownload}
                className="p-3 rounded-full hover:bg-black/5 active:bg-black/10 transition-colors"
                aria-label="Download Image"
                disabled={!content || isLoading}
            >
                <Download size={20} />
            </button>
          </div>

          <button 
            onClick={onGenerate}
            disabled={isLoading}
            className={`mx-2 px-6 py-3 rounded-full font-medium shadow-lg active:scale-95 transition-all flex items-center space-x-2 ${getButtonStyles()} ${isLoading ? 'opacity-80 cursor-wait' : ''}`}
          >
            <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''} />
            <span>{content ? 'Retry' : 'Create'}</span>
          </button>

          <button 
            onClick={() => content && onSave(content)}
            className="p-3 rounded-full hover:bg-black/5 active:bg-black/10 transition-colors"
            aria-label="Save"
            disabled={!content || isLoading}
          >
            {isSaved ? <BookmarkCheck size={20} className="fill-current" /> : <Bookmark size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContentCard;