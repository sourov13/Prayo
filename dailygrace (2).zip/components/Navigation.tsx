import React from 'react';
import { Sun, Moon, Heart, Bookmark, Calendar } from 'lucide-react';
import { AppTab } from '../types';

interface NavigationProps {
  currentTab: AppTab;
  onTabChange: (tab: AppTab) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentTab, onTabChange }) => {
  const navItems = [
    { id: AppTab.Morning, label: 'Today', icon: Sun },
    { id: AppTab.Night, label: 'Tonight', icon: Moon },
    { id: AppTab.Relationships, label: 'Love', icon: Heart },
    { id: AppTab.Calendar, label: 'Plan', icon: Calendar },
    { id: AppTab.Saved, label: 'Saved', icon: Bookmark },
  ];

  return (
    // pb-safe is defined in index.html to use safe-area-inset-bottom
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-gray-100 pb-safe z-50 shadow-[0_-5px_20px_-5px_rgba(0,0,0,0.05)]">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto px-2">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;
          
          let activeColorClass = "text-gray-900";
          if (isActive) {
            if (item.id === AppTab.Morning) activeColorClass = "text-dawn-500";
            if (item.id === AppTab.Night) activeColorClass = "text-dusk-500";
            if (item.id === AppTab.Relationships) activeColorClass = "text-rose-500";
            if (item.id === AppTab.Calendar) activeColorClass = "text-gray-800";
          } else {
            activeColorClass = "text-gray-400";
          }

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1.5 active:scale-95 transition-all duration-200 ${activeColorClass}`}
            >
              <div className={`relative p-1 rounded-xl transition-all ${isActive ? 'bg-gray-50' : ''}`}>
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[9px] font-medium tracking-wide ${isActive ? 'opacity-100' : 'opacity-70'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default Navigation;