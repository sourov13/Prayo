import { GoogleGenAI } from "@google/genai";
import { AppTab, GeneratedContent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_ID = 'gemini-2.5-flash';

const PROMPTS = {
  [AppTab.Morning]: "Write a short, uplifting, and spiritual 'Prayer for Today'. Focus on hope, gratitude, and strength for the day ahead. Keep it under 100 words. Do not use markdown formatting like bold or italics.",
  [AppTab.Night]: "Write a calming, peaceful 'When You Pray Tonight' reflection. Focus on letting go of anxiety, finding rest, and gratitude for the day passed. Keep it under 100 words. Do not use markdown formatting.",
  [AppTab.Relationships]: "Write a profound and helpful relationship quote or piece of advice. Focus on love, patience, communication, or forgiveness. Keep it concise (under 60 words). Do not use markdown formatting."
};

export const generateContent = async (type: AppTab): Promise<GeneratedContent> => {
  try {
    const prompt = PROMPTS[type];
    
    // Adding a random seed variation to the prompt to ensure freshness
    const themes = [
      "gratitude", "patience", "hope", "courage", "peace", 
      "understanding", "forgiveness", "joy", "resilience", "faith"
    ];
    const randomTheme = themes[Math.floor(Math.random() * themes.length)];
    const finalPrompt = `${prompt} Incorporate the theme of '${randomTheme}'.`;

    const response = await ai.models.generateContent({
      model: MODEL_ID,
      contents: finalPrompt,
    });

    const text = response.text?.trim() || "Unable to generate content at this time. Please try again.";

    return {
      id: crypto.randomUUID(),
      text,
      type,
      timestamp: Date.now(),
      theme: randomTheme
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to connect to the spiritual guide.");
  }
};